<?php

namespace App\Http\Controllers;

use App\Models\Accounts;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Hash;

class AccountController extends Controller
{
    public function index_login(){
        return view('authentication.login');
    }

    public function login(Request $request){
        $credential = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8'
        ]);

        if(!Auth::attempt($credential)){
            return redirect()->back()->withErrors('Invalid Credential!');
        }

        if($request->remember){
            Cookie::queue('CookieEmail',$request->email,60);
            Cookie::queue('CookiePassword',$request->password,60);
        }


        return redirect()->route('index_home');

    }

    //A Function To Display Register Page
    public function index_register(){
        return view('authentication.register');
    }

    //A Function To Handle Register
    public function register(Request $request){
        //INSERT CODE HERE
        $request->validate([
            'first_name' => 'required|regex:/^[\w\s]+$/|max:25',
            'last_name' => 'required|regex:/^[\w\s]+$/|max:25',
            'email' => 'required|unique:users,email|email',
            'role' => 'required|digits_between:1,2',
            'gender' => 'required|digits_between:1,2',
            'image' => 'required|file|image',
            'password' => 'required|min:8|alpha_num|regex:/[0-9]/',
            'confirm' => 'required|min:8|alpha_num|regex:/[0-9]/|same:password'
        ]);

        $destinationPath = 'profile_image';
        $myimage = $request->image->getClientOriginalName();
        $request->image->move(public_path($destinationPath), $myimage);

        User::create([
            'first_name'=>$request->first_name,
            'last_name'=>$request->last_name,
            'email'=>$request->email,
            'role_id'=>$request->role,
            'gender_id'=>$request->gender,
            'display_picture_link'=>$myimage,
            'password'=>Hash::make($request->input('password'))
        ]);

        return redirect()->route('index_login');
    }

    // A Function To Handle Logout
    public function logout(){
        Auth::logout();
        return redirect()->route('index_logoutsuccess');
    }

    public function updateProfile(Request $request){
        $request->validate([
            'first_name' => 'required|regex:/^[\w\s]+$/|max:25',
            'last_name' => 'required|regex:/^[\w\s]+$/|max:25',
            'email' => 'required|email',
            'gender' => 'required|digits_between:1,2',
            'image' => 'nullable|file|image',
            'password' => 'required|min:8|alpha_num|regex:/[0-9]/',
            'newPassword' => 'nullable|min:8|alpha_num|regex:/[0-9]/'
        ]);

        if(!Hash::check($request->input('password'),Auth::user()->password )){
            return redirect()->back()->withErrors('Incorrect Current Password');
        }

        if($request->input('email') !== Auth::user()->email){
            $request->validate([
                'email' => 'required|email|unique:users,email'
            ]);
        }

        if($request->image !== null){
            $destinationPath = 'profile_image';
            $myimage = $request->image->getClientOriginalName();
            $request->image->move(public_path($destinationPath), $myimage);
            User::where("account_id", "=", Auth::user()->account_id)->update([
                'display_picture_link' => $myimage
            ]);


        }


        User::where("account_id", "=", Auth::user()->account_id)->update([
            'first_name'=>$request->first_name,
            'last_name'=>$request->last_name,
            'email'=>$request->email,
            'gender_id'=>$request->gender,
        ]);

        if($request->input('newPassword') != null){
            User::where("account_id", "=", Auth::user()->account_id)->update([
                'password' => Hash::make($request->input('newPassword'))
            ]);
        }

        return redirect()->route('index_savedsuccess');
    }

    public function account_maintenance(){
        $user = User::all();
        return view('authentication.accMaintenance', compact('user'));
    }

    public function index_profile(){
        $user = Auth::user();
        return view('authentication.profile', compact('user'));
    }

    public function index_update($id){
        $user = User::where('account_id', '=', $id)->first();
        return view('authentication.updateRole', compact('user'));
    }

    public function update_role($id, Request $request){
        $request->validate([
            'role' => 'required|digits_between:1,2'
        ]);

        User::where('account_id', "=" , $id)->update([
            'role_id' => $request->role
        ]);

        return redirect()->route('account_maintenance');
    }

    public function delete_account($id){
        User::where('account_id', "=" , $id)->delete();
        return redirect()->route('account_maintenance');
    }
}
