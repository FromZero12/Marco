<?php

namespace App\Http\Controllers;

use App\Models\Items;
use Illuminate\Http\Request;

class ItemController extends Controller
{
    //
    public function view_product ($id) {
        $item = Items::where('item_id', 'like', $id)->first();
        return view('item.item', compact('item'));
    }

    
}
