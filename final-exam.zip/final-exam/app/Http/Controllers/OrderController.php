<?php

namespace App\Http\Controllers;

use App\Models\Orders;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    //
    public function buy_item($id){
        Orders::create([
            'account_id'=>Auth::user()->account_id,
            'item_id'=>$id
        ]);

        return redirect()->route('index_cart');
    }

    public function index_cart(){
        $myCart = Orders::where('account_id', 'like', Auth::user()->account_id)->get();
        return view('cart.cart', compact('myCart'));
    }

    public function delete_order($id){
        Orders::where('order_id', '=', $id)->delete();
        return redirect()->back();
    }

    public function checkout(){
        Orders::where('account_id', '=', Auth::user()->account_id)->delete();
        return redirect()->route('index_cosucess');
    }
}
