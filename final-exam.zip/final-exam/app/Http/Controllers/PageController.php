<?php

namespace App\Http\Controllers;

use App\Models\Items;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\App;

class PageController extends Controller
{
    //
    public function index_home(){
        $item = Items::paginate(10);
        return view('home', compact('item'));
    }

    public function index_welcome(){
        return view('welcome');
    }

    public function index_cosucess(){
        return view('success.cosucess');
    }

    public function index_savedsuccess(){
        return view('success.savedsuccess');
    }

    public function index_logoutsuccess(){
        return view('success.logoutsuccess');
    }

    public function language(){
        App::setLocale("id");
        return view('authentication.login');
    }
}
