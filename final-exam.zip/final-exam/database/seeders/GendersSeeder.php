<?php

namespace Database\Seeders;

use App\Models\Genders;
use Illuminate\Database\Seeder;

class GendersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //

        Genders::create(['gender_desc' => "male"]);
        Genders::create(['gender_desc' => "female"]);
    }
}
