@extends('templete.templete')

@section('title', 'Account Maintenance')

@section('content')

<div class="d-flex justify-content-center align-items-center m-5">
    <table class="table table-bordered text-black text-center w-50">
        <thead>
            <tr>
                <th>@lang('attribute.account')</th>
                <th colspan=2>@lang('attribute.action')</th>
            </tr>
        </thead>
        <tbody>
            @foreach($user as $u)
                <tr>
                    <td>{{ $u->first_name}} {{$u->last_name}} - {{$u->role->role_name}}</td>
                    <td>
                        <div class="d-flex flex-row justify-content-center align-items-center">
                            <a href="{{route('index_update', $u->account_id)}}" type="button" class="btn btn-orange mx-1">@lang('attribute.update')</a>
                            <form action="{{route('delete_account', $u->account_id)}}" method="POST" enctype="multipart/form-data">
                                @csrf
                                @method('delete')
                                <button type="submit"  class="btn btn-orange mx-1">@lang('attribute.delete')</button>
                            </form>
                        </div>

                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>

@endsection
