@extends('templete.templete')

@section('title', 'Login')

@section('content')
<div class="my-5 w-100">
    <div class="mx-5 my-3 text-black fs-1 text-decoration-underline text-center">
       @lang('attribute.Login')
    </div>

    <div class="w-100 px-5">
        <form action="{{route('login')}}" method="POST" enctype="multipart/form-data" class="d-flex flex-column w-100">
            @csrf
            <div class="d-flex flex-column w-100 align-items-center">
                <div class="mb-2 d-flex flex-column align-items-start w-50">
                    <label for="email" class="form-label text-black">Email: </label>
                    <input type="text" name="email" class="form-control text-dark-blue" id="email" placeholder="email" value="{{Cookie::get('CookieEmail') !== null ? Cookie::get('CookieEmail'): "" }}">
                </div>
                <div class="mb-2 d-flex flex-column align-items-start w-50" >
                    <label for="last_name" class="form-label text-black">Password:</label>
                    <input type="password" name="password" class="form-control text-dark-blue" id="password" placeholder="password" value="{{Cookie::get('CookiePassword') !== null ? Cookie::get('CookiePassword'): "" }}">
                </div>
            </div>
            <div class="form-check d-flex justify-content-center gap-2">
                <input class="form-check-input" type="checkbox" name="remember" id="remember" checked={{Cookie::get('CookieEmail')!== null }}>
                <label class="form-check-label text-dark-blue" for="remember">
                Remember Me
                </label>
            </div>
            <div class="mb-0">
                @if ($errors->any())
                    <p class="text-danger mb-2 text-center">{{$errors->first()}}</p>
                @endif
            </div>
            <div class="mb-4 mt-2 d-flex justify-content-center">
                <button type="submit" class="btn btn-orange w-50">@lang('attribute.submit')</button>
            </div>
        </form>
        {{-- <hr> --}}
        <p class="text-black text-center"><a class="text-red" href="{{route('register')}}">@lang('attribute.no_account')</a></p>
    </div>

</div>

@endsection
