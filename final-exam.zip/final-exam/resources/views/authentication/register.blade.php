@extends('templete.templete')

@section('title', 'Register')

@section('content')

<div class="my-5 w-100">
    <div class="mx-5 my-3 text-black fs-1 text-decoration-underline text-center">
        @lang('attribute.register')
    </div>

    <div class="w-100 px-5">
        <form action="{{route('register')}}" method="POST" enctype="multipart/form-data" class="d-flex flex-column w-100">
        @csrf

        <div class="d-flex flex-row w-100">
            <div class="mb-2 d-flex flex-column align-items-start w-50 me-2">
                <label for="first_name" class="form-label text-black">@lang('attribute.fname')</label>
                <input type="text" name="first_name" class="form-control text-dark-blue" id="first_name" placeholder="First name">
            </div>
            <div class="mb-2 d-flex flex-column align-items-start w-50 ms-2" >
                <label for="last_name" class="form-label text-black">@lang('attribute.lname')</label>
                <input type="text" name="last_name" class="form-control text-dark-blue" id="last_name" placeholder="Last name">
            </div>
        </div>

        <div class="d-flex flex-row w-100">
            <div class="mb-2 d-flex flex-column align-items-start w-50 me-2">
                <label for="email" class="form-label text-black">Email: </label>
                <input type="text" name="email" class="form-control text-dark-blue" id="email" placeholder="email">
            </div>
            <div class="mb-2 d-flex flex-column align-items-start w-50 ms-2">
                <label for="role" class="form-label text-black">@lang('attribute.role')</label>
                <select name="role" required class="w-100 h-100 px-2">
                    <option value="">Role</option>
                    <option value="1">Admin</option>
                    <option value="2">User</option>
                </select>
            </div>
        </div>

        <div class="d-flex flex-row w-100">
            <div class="mb-2 d-flex flex-column align-items-start w-50 me-2">
                <label for="email" class="form-label text-black">@lang('attribute.gender') </label>
                <div class="d-flex align-items-center w-100 h-100">
                    <div class="form-check me-2">
                        <input class="form-check-input " type="radio" name="gender" id="male" value="1">
                        <label class="form-check-label me-1 text-black" for="male">
                            @lang('attribute.male')
                        </label>
                    </div>
                    <div class="form-check ms-2">
                        <input class="form-check-input" type="radio" name="gender" id="female" value="2">
                        <label class="form-check-label text-black" for="female">
                            @lang('attribute.female')
                        </label>
                    </div>
                </div>
            </div>
            <div class="mb-2 d-flex flex-column align-items-start w-50 ms-2">
                <label for="image" class="form-label text-black">@lang('attribute.profile_image') </label>
                <input type="file" name="image" id="image" class="form-control text-dark-blue" accept="image/*">
            </div>
        </div>

        <div class="d-flex flex-row w-100">
            <div class="mb-2 d-flex flex-column align-items-start w-50 me-2">
                <label for="password" class="form-label text-black">Password</label>
                <input type="password" name="password" class="form-control text-dark-blue" id="password" placeholder="Password">
            </div>
            <div class="mb-2 d-flex flex-column align-items-start w-50 ms-2">
                <label for="confirm" class="form-label text-black">@lang('attribute.confirm')</label>
                <input type="password" name="confirm" class="form-control text-dark-blue" id="confirm" placeholder="Re-type your password">
            </div>
        </div>
        <div class="mb-2">
            @if ($errors->any())
                <p class="text-danger">{{$errors->first()}}</p>
            @endif
        </div>
        <div class="my-4 d-flex justify-content-center">
            <button type="submit" class="btn btn-orange w-50">@lang('attribute.submit')</button>
        </div>
        </form>
        {{-- <hr> --}}
        <p class="text-black text-center"><a class="text-red"  href="{{route('index_login')}}">@lang('attribute.has_account')</a></p>
    </div>

</div>
@endsection
