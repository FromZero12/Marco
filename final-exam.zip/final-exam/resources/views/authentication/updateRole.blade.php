@extends('templete.templete')

@section('title', 'Update Role')

@section('content')
<div class="d-flex m-5 justify-content-center align-items-center" >
    <form action="{{route('update_role', $user->account_id)}}" method="post" enctype="multipart/form-data">
        @csrf
        @method('patch')
        <div class="mt-5 mb-3 text-black fs-1 text-decoration-underline text-center">
            {{$user->first_name}} {{$user->last_name}}
         </div>
        <div class="my-3 d-flex flex-column align-items-center">
            <label for="role" class="form-label text-black">@lang('attribute.role')</label>
            <select name="role" required class="w-100 h-100 px-2">
                <option value="">Role</option>
                <option value="1">Admin</option>
                <option value="2">User</option>
            </select>
        </div>
        <button type="submit" class="btn btn-orange w-100 mb-5">@lang('attribute.save')</button>
    </form>
    </div>
@endsection
