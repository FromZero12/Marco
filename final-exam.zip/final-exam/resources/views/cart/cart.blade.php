@extends('templete.templete')

@section('title', 'My cart')

@section('content')
    <div class="mx-5 mb-3 mt-5 text-black fs-1 text-decoration-underline text-center">
        @lang('attribute.cart')
    </div>
    @php
        $price = 0;
    @endphp
    @if ($myCart->isEmpty())
        <h1 class="text-black display-5 text-center my-5">@lang('attribute.empty_cart')</h1>
    @else
        <div class="container mb-5">
            <div class="row justify-content-center">
                <div class="col-12">
                    <table class="table table-bordered text-black text-center">
                        <thead>
                            <tr>
                                <th>@lang('attribute.item_image')</th>
                                <th>@lang('attribute.item_name')</th>
                                <th>@lang('attribute.item_price')</th>
                                <th colspan=2>@lang('attribute.action')</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($myCart as $order)
                                <tr>
                                    <td> <img src="{{asset('item_image/'.$order->item->display_picture_link)}}" class="card-img-top" alt="" style="height: 300px;width:300px;"></td>
                                    <td>{{ $order->item->item_name }}</td>
                                    <td>{{ $order->item->price }}</td>
                                    <td>
                                        <form method="POST" action="{{route('delete_order', $order->order_id) }}" class="w-100" enctype="multipart/form-data"  >
                                            @csrf

                                            @method('delete')
                                            <button class="btn btn-orange w-100" type="submit">@lang('attribute.delete')</button>
                                        </form>
                                    </td>
                                </tr>
                                @php
                                    $price += $order->item->price;
                                @endphp
                            @endforeach
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-between w-100">
                        <h5 class="text-black">@lang('attribute.total_price') : IDR {{$price}}</h5>
                        <form action="{{route('checkout')}}" method="POST" style="width: 48%" class="d-flex justify-content-end" enctype="multipart/form-data">
                            @csrf
                            <button type="submit"  class="btn btn-orange w-25">Checkout</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    @endif
@endsection
