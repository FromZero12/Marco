@extends('templete.templete')

@section('title', 'Home')

@section('content')
    <div class="row row-cols-1 row-cols-md-5 g-3 my-5">
        @foreach ($item as $p)
        <div class="col">
            <div class="d-flex flex-column align-items-center">
                <img src="{{asset('item_image/'.$p->display_picture_link)}}" class="card-img-top" alt="" style="height: 200px;width:200px;border-radius:50%; border:2px solid black;">
                <h5 class="card-title mt-2">{{$p->item_name}}</h5>
                <a href="/item/{{$p->item_id}}" class="">@lang('attribute.detail_item')</a>
            </div>
        </div>
        @endforeach
    </div>

    <div class="d-flex justify-content-center align-items-center">
        {{$item->links()}}
    </div>

@endsection
