@extends('templete.templete')

@section('title', 'Item')

@section('content')
<div class="my-5 w-100">
    <div class="mx-5 my-3 text-black fs-1 text-decoration-underline">
       {{$item->item_name}}
    </div>

    <div class="w-100 px-5 d-flex flex-row">
        <div class="me-2">
            <img src="{{asset('item_image/'.$item->display_picture_link)}}" class="img-fluid rounded" alt="..." width="600px" height="600px;">
        </div>
        <div class="d-flex flex-column w-100">
            <div class="mx-3 mt-3 text-black fs-3 fw-bold">
                Rp.{{$item->price}},-
             </div>
             <div class="mx-3 my-3 text-black fs-3-center">
                {{$item->item_desc}}
             </div>
             <form action="{{route('buy_item', $item->item_id)}}" method="POST" enctype="multipart/form-data" class="mx-3 my-3">
                @csrf
                <button type="submit" class="btn btn-orange" style="width: 150px;">@lang('attribute.purchase')</button>
            </form>
        </div>
    </div>

</div>
@endsection
