@extends('templete.templete')

@section('title', 'Checkout Success')

@section('content')
<div class="bg-light d-flex justify-content-center">
    <div class="bg-white d-flex flex-column align-items-center justify-content-center rounded-circle m-5 p-1 text-black text-center" style="width: 600px;height: 600px; border: 15px solid #F05A2A;">
        <p class="fw-bold fs-1">@lang('attribute.saved')</p>
        <a class="fs-3" href="{{route('index_home')}}">@lang('attribute.click_home')</a>
    </div>

</div>
@endsection
