<Footer>
    <div class="d-flex justify-content-center align-items-center green-background text-white fs-5 p-3">
        © Amazing E-Grocery 2023
    </div>
</Footer>
