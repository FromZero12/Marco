<Header>
    <div class="d-flex green-background justify-content-between align-items-center p-4">
        <div>
            <h1 class="text-white ms-5 fw-bold fs-1">
                Amazing E-Grocery
            </h1>
        </div>
        <div class="d-flex flex-row align-items-center">
            <div class="nav-item dropdown">
                <form action="{{ route('locale.setting', 'id') }}" method="Get" class="">
                    <button type="submit" class="btn btn-orange" type="button">Bahasa</button>
                </form>
             </div>
             <div class="nav-item dropdown me-5">
                <form action="{{ route('locale.setting', 'en') }}" method="Get" class="">
                    <button type="submit" class="btn btn-orange me-5" type="button">English</button>
                </form>
             </div>
            @if (!Auth::check())
                <form class="d-flex" role="right">
                    <div class="ms-auto pe-2">
                        <button class="btn btn-orange mx-0" type="button"><a class="nav-link active" href="{{route('index_register')}}">@lang('attribute.register')</a></button>
                        <button class="btn btn-orange me-5" type="button"><a class="nav-link active" href="{{route('index_login')}}">@lang('attribute.Login')</a></button>
                    </div>
                </form>
            @else
                <form action="{{route('logout')}}" method="POST" class="">
                    @csrf
                    <button type="submit" class="btn btn-orange me-5" type="button">@lang('attribute.logout')</button>
                </form>
            @endif
        </div>
    </div>
</Header>
