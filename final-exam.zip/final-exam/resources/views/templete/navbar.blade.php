@auth
<nav>
    <div class="d-flex justify-content-evenly aligns-items-center w-100 orange-background p-2">
        <a class="nav-link text-white fw-bold fs-5" aria-current="page" href="{{route('index_home')}}">@lang('attribute.home')</a>
        <a class="nav-link text-white fw-bold fs-5" href="{{route('index_cart')}}">@lang('attribute.cart')</a>
        <a class="nav-link text-white fw-bold fs-5" href="{{route('index_profile')}}">@lang('attribute.profile')</a>
        @if (Auth::user()->role_id == 1)
            <a class="nav-link text-white fw-bold fs-5" href="{{route('account_maintenance')}}">@lang('attribute.acc_maintain')</a>
        @endif
    </div>
</nav>
@endauth



