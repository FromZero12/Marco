@extends('templete.templete')

@section('title', 'Welcome')

@section('content')
<div class="bg-light d-flex justify-content-center">
    <div class="bg-white d-flex align-items-center rounded-circle m-5 p-1 fs-1 fw-bold text-black text-center" style="width: 600px;height: 600px; border: 15px solid #F05A2A;">
        @lang('attribute.welcome')
    </div>

</div>
@endsection
