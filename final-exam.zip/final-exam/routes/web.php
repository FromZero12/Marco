<?php

use App\Http\Controllers\AccountController;
use App\Http\Controllers\ItemController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PageController;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

















Route::middleware(['isGuest', 'language'])->group(function () {
    Route::get('/logout/success', [PageController::class, 'index_logoutsuccess'])->name('index_logoutsuccess');
    Route::get('/', [PageController::class, 'index_welcome'])->name('index_welcome');
    Route::get('/auth/login', [AccountController::class, 'index_login'])->name('index_login');
    Route::get('/auth/register', [AccountController::class, 'index_register'])->name('index_register');
    Route::post('/auth/login', [AccountController::class, 'login'])->name('login');
    Route::post('/auth/register', [AccountController::class, 'register'])->name('register');
});

Route::middleware(['isAdmin', 'language'])->group(function () {
    Route::get('/account/maintenance', [AccountController::class, 'account_maintenance'])->name("account_maintenance");
    Route::delete('/delete/account/{id}', [AccountController::class, 'delete_account'])->name('delete_account');
    Route::get('/update/role/{id}', [AccountController::class, 'index_update'])->name('index_update');
    Route::patch('/update/role/{id}', [AccountController::class, 'update_role'])->name('update_role');
});

Route::middleware(['isUser', 'language'])->group(function () {
    Route::get('/home', [PageController::class, 'index_home'])->name('index_home');
    Route::get("/profile", [AccountController::class, 'index_profile'])->name('index_profile');
    Route::get("/item/{id}", [ItemController::class, 'view_product'])->name('view_product');
    Route::get('/cart',[OrderController::class, 'index_cart'])->name('index_cart');
    Route::post('/logout', [AccountController::class, 'logout'])->name('logout');
    Route::post('/updateProfile', [AccountController::class, 'updateProfile'])->name('updateProfile');
    Route::post("/buy/item/{id}", [OrderController::class, 'buy_item'])->name('buy_item');
    Route::delete('/delete/order/{id}', [OrderController::class, 'delete_order'])->name('delete_order');
    Route::post('/checkout', [OrderController::class, 'checkout'])->name('checkout');
    Route::get('/checkout/success', [PageController::class, 'index_cosucess'])->name('index_cosucess');
    Route::get('/saved/success', [PageController::class, 'index_savedsuccess'])->name('index_savedsuccess');
});

Route::get('set-locale/{locale}', function ($locale) {
    App::setLocale($locale);
    session()->put('locale', $locale);
    return redirect()->back();
})->middleware('language')->name('locale.setting');
