<?php $__env->startSection('title', 'Account Maintenance'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-center align-items-center m-5">
    <table class="table table-bordered text-black text-center w-50">
        <thead>
            <tr>
                <th><?php echo app('translator')->get('attribute.account'); ?></th>
                <th colspan=2><?php echo app('translator')->get('attribute.action'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($u->first_name); ?> <?php echo e($u->last_name); ?> - <?php echo e($u->role->role_name); ?></td>
                    <td>
                        <div class="d-flex flex-row justify-content-center align-items-center">
                            <a href="<?php echo e(route('index_update', $u->account_id)); ?>" type="button" class="btn btn-orange mx-1"><?php echo app('translator')->get('attribute.update'); ?></a>
                            <form action="<?php echo e(route('delete_account', $u->account_id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit"  class="btn btn-orange mx-1"><?php echo app('translator')->get('attribute.delete'); ?></button>
                            </form>
                        </div>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templete.templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\OneDrive\Documents\Semester 5\Web Programming\final-exam\resources\views/authentication/accMaintenance.blade.php ENDPATH**/ ?>