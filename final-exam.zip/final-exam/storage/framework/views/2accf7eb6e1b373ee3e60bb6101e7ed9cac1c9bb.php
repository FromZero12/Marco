<?php $__env->startSection('title', 'Update Role'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex m-5 justify-content-center align-items-center" >
    <form action="<?php echo e(route('update_role', $user->account_id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <div class="mt-5 mb-3 text-black fs-1 text-decoration-underline text-center">
            <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

         </div>
        <div class="my-3 d-flex flex-column align-items-center">
            <label for="role" class="form-label text-black"><?php echo app('translator')->get('attribute.role'); ?></label>
            <select name="role" required class="w-100 h-100 px-2">
                <option value="">Role</option>
                <option value="1">Admin</option>
                <option value="2">User</option>
            </select>
        </div>
        <button type="submit" class="btn btn-orange w-100 mb-5"><?php echo app('translator')->get('attribute.save'); ?></button>
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templete.templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\OneDrive\Documents\Semester 5\Web Programming\final-exam\resources\views/authentication/updateRole.blade.php ENDPATH**/ ?>