<?php $__env->startSection('title', 'Welcome'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-light d-flex justify-content-center">
    <div class="bg-white d-flex align-items-center rounded-circle m-5 p-1 fs-1 fw-bold text-black text-center" style="width: 600px;height: 600px; border: 15px solid #F05A2A;">
        <?php echo app('translator')->get('attribute.welcome'); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templete.templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\OneDrive\Documents\Semester 5\Web Programming\final-exam\resources\views/welcome.blade.php ENDPATH**/ ?>