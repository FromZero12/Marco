<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row row-cols-1 row-cols-md-5 g-3 my-5">
        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="d-flex flex-column align-items-center">
                <img src="<?php echo e(asset('item_image/'.$p->display_picture_link)); ?>" class="card-img-top" alt="" style="height: 200px;width:200px;border-radius:50%; border:2px solid black;">
                <h5 class="card-title mt-2"><?php echo e($p->item_name); ?></h5>
                <a href="/item/<?php echo e($p->item_id); ?>" class=""><?php echo app('translator')->get('attribute.detail_item'); ?></a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="d-flex justify-content-center align-items-center">
        <?php echo e($item->links()); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templete.templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\OneDrive\Documents\Semester 5\Web Programming\final-exam\resources\views/home.blade.php ENDPATH**/ ?>