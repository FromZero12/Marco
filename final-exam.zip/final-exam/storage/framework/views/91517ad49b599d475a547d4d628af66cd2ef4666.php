<?php if(auth()->guard()->check()): ?>
<nav>
    <div class="d-flex justify-content-evenly aligns-items-center w-100 orange-background p-2">
        <a class="nav-link text-white fw-bold fs-5" aria-current="page" href="<?php echo e(route('index_home')); ?>"><?php echo app('translator')->get('attribute.home'); ?></a>
        <a class="nav-link text-white fw-bold fs-5" href="<?php echo e(route('index_cart')); ?>"><?php echo app('translator')->get('attribute.cart'); ?></a>
        <a class="nav-link text-white fw-bold fs-5" href="<?php echo e(route('index_profile')); ?>"><?php echo app('translator')->get('attribute.profile'); ?></a>
        <?php if(Auth::user()->role_id == 1): ?>
            <a class="nav-link text-white fw-bold fs-5" href="<?php echo e(route('account_maintenance')); ?>"><?php echo app('translator')->get('attribute.acc_maintain'); ?></a>
        <?php endif; ?>
    </div>
</nav>
<?php endif; ?>



<?php /**PATH C:\Users\Asus\OneDrive\Documents\Semester 5\Web Programming\final-exam\resources\views/templete/navbar.blade.php ENDPATH**/ ?>