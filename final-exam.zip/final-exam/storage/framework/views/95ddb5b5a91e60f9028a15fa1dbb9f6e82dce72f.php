<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>

<div class="my-5 w-100">
    <div class="mx-5 my-3 text-black fs-1 text-decoration-underline text-center">
        <?php echo app('translator')->get('attribute.profile'); ?>
    </div>


    <div class="w-100 px-5 d-flex flex-row">
        <div class="me-3">
            <img src="<?php echo e(asset('profile_image/'.$user->display_picture_link)); ?>" class="img-fluid rounded-start" alt="..." width="480px" height="480px">
        </div>
        <form action="<?php echo e(route('updateProfile')); ?>" method="POST" enctype="multipart/form-data" class="d-flex flex-column w-100">
        <?php echo csrf_field(); ?>

        <div class="d-flex flex-row w-100">
            <div class="mb-2 d-flex flex-column align-items-start w-50 me-2">
                <label for="first_name" class="form-label text-black"><?php echo app('translator')->get('attribute.fname'); ?></label>
                <input type="text" name="first_name" class="form-control text-dark-blue" id="first_name" placeholder="First name" value="<?php echo e($user->first_name); ?>">
            </div>
            <div class="mb-2 d-flex flex-column align-items-start w-50 ms-2" >
                <label for="last_name" class="form-label text-black"><?php echo app('translator')->get('attribute.lname'); ?></label>
                <input type="text" name="last_name" class="form-control text-dark-blue" id="last_name" placeholder="Last name" value="<?php echo e($user->last_name); ?>">
            </div>
        </div>

        <div class="d-flex flex-row w-100">
            <div class="mb-2 d-flex flex-column align-items-start w-50 me-2">
                <label for="email" class="form-label text-black">Email: </label>
                <input type="text" name="email" class="form-control text-dark-blue" id="email" placeholder="email" value="<?php echo e($user->email); ?>">
            </div>
            <div class="mb-2 d-flex flex-column align-items-start w-50 ms-2">
                <label for="role" class="form-label text-black"><?php echo app('translator')->get('attribute.role'); ?></label>
                <select name="role" required class="w-100 h-100 px-2" disabled>
                    <option value="1" <?php echo e(($user->role_id=="1")? "selected" : ""); ?>>Admin</option>
                    <option value="2" <?php echo e(($user->role_id=="2")? "selected" : ""); ?>>User</option>
                </select>
            </div>
        </div>

        <div class="d-flex flex-row w-100">
            <div class="mb-2 d-flex flex-column align-items-start w-50 me-2">
                <label for="email" class="form-label text-black"><?php echo app('translator')->get('attribute.gender'); ?> </label>
                <div class="d-flex align-items-center w-100 h-100">
                    <div class="form-check me-2">
                        <input class="form-check-input " type="radio" name="gender" id="male" value="1" <?php echo e(($user->gender_id=="1")? "checked" : ""); ?>>
                        <label class="form-check-label me-1 text-black" for="male" >
                            <?php echo app('translator')->get('attribute.male'); ?>
                        </label>
                    </div>
                    <div class="form-check ms-2">
                        <input class="form-check-input" type="radio" name="gender" id="female" value="2" <?php echo e(($user->gender_id=="2")? "checked" : ""); ?>>
                        <label class="form-check-label text-black" for="female">
                            <?php echo app('translator')->get('attribute.female'); ?>
                        </label>
                    </div>
                </div>
            </div>
            <div class="mb-2 d-flex flex-column align-items-start w-50 ms-2">
                <label for="image" class="form-label text-black"><?php echo app('translator')->get('attribute.profile_image'); ?> </label>
                <input type="file" name="image" id="image" class="form-control text-dark-blue" accept="image/*">
            </div>
        </div>

        <div class="d-flex flex-row w-100">
            <div class="mb-2 d-flex flex-column align-items-start w-50 me-2">
                <label for="password" class="form-label text-black"><?php echo app('translator')->get('attribute.curr_pass'); ?></label>
                <input type="password" name="password" class="form-control text-dark-blue" id="password" placeholder="Password">
            </div>
            <div class="mb-2 d-flex flex-column align-items-start w-50 ms-2">
                <label for="confirm" class="form-label text-black"><?php echo app('translator')->get('attribute.new_pass'); ?></label>
                <input type="password" name="newPassword" class="form-control text-dark-blue" id="confirm" placeholder="Re-type your password"">
            </div>
        </div>
        <div class="mb-2">
            <?php if($errors->any()): ?>
                <p class="text-danger"><?php echo e($errors->first()); ?></p>
            <?php endif; ?>
        </div>
        <div class="my-4 d-flex justify-content-center">
            <button type="submit" class="btn btn-orange w-50"><?php echo app('translator')->get('attribute.save'); ?></button>
        </div>
        </form>
        
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templete.templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\OneDrive\Documents\Semester 5\Web Programming\final-exam\resources\views/authentication/profile.blade.php ENDPATH**/ ?>