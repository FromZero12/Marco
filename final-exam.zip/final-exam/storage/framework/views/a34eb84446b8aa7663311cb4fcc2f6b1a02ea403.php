<?php $__env->startSection('title', 'My cart'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mx-5 mb-3 mt-5 text-black fs-1 text-decoration-underline text-center">
        <?php echo app('translator')->get('attribute.cart'); ?>
    </div>
    <?php
        $price = 0;
    ?>
    <?php if($myCart->isEmpty()): ?>
        <h1 class="text-black display-5 text-center my-5"><?php echo app('translator')->get('attribute.empty_cart'); ?></h1>
    <?php else: ?>
        <div class="container mb-5">
            <div class="row justify-content-center">
                <div class="col-12">
                    <table class="table table-bordered text-black text-center">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('attribute.item_image'); ?></th>
                                <th><?php echo app('translator')->get('attribute.item_name'); ?></th>
                                <th><?php echo app('translator')->get('attribute.item_price'); ?></th>
                                <th colspan=2><?php echo app('translator')->get('attribute.action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $myCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <img src="<?php echo e(asset('item_image/'.$order->item->display_picture_link)); ?>" class="card-img-top" alt="" style="height: 300px;width:300px;"></td>
                                    <td><?php echo e($order->item->item_name); ?></td>
                                    <td><?php echo e($order->item->price); ?></td>
                                    <td>
                                        <form method="POST" action="<?php echo e(route('delete_order', $order->order_id)); ?>" class="w-100" enctype="multipart/form-data"  >
                                            <?php echo csrf_field(); ?>

                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-orange w-100" type="submit"><?php echo app('translator')->get('attribute.delete'); ?></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php
                                    $price += $order->item->price;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-between w-100">
                        <h5 class="text-black"><?php echo app('translator')->get('attribute.total_price'); ?> : IDR <?php echo e($price); ?></h5>
                        <form action="<?php echo e(route('checkout')); ?>" method="POST" style="width: 48%" class="d-flex justify-content-end" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <button type="submit"  class="btn btn-orange w-25">Checkout</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templete.templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\OneDrive\Documents\Semester 5\Web Programming\final-exam\resources\views/cart/cart.blade.php ENDPATH**/ ?>