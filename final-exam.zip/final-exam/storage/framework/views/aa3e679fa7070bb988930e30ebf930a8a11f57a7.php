<?php $__env->startSection('title', 'Checkout Success'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-light d-flex justify-content-center">
    <div class="bg-white d-flex flex-column align-items-center justify-content-center rounded-circle m-5 p-1 text-black text-center" style="width: 600px;height: 600px; border: 15px solid #F05A2A;">
        <p class="fw-bold fs-1"><?php echo app('translator')->get('attribute.saved'); ?></p>
        <a class="fs-3" href="<?php echo e(route('index_home')); ?>"><?php echo app('translator')->get('attribute.click_home'); ?></a>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templete.templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\OneDrive\Documents\Semester 5\Web Programming\final-exam\resources\views/success/savedsuccess.blade.php ENDPATH**/ ?>