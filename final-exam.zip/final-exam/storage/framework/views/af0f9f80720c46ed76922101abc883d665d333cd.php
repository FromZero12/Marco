<Header>
    <div class="d-flex green-background justify-content-between align-items-center p-4">
        <div>
            <h1 class="text-white ms-5 fw-bold fs-1">
                Amazing E-Grocery
            </h1>
        </div>
        <div class="d-flex flex-row align-items-center">
            <div class="nav-item dropdown">
                <form action="<?php echo e(route('locale.setting', 'id')); ?>" method="Get" class="">
                    <button type="submit" class="btn btn-orange" type="button">Bahasa</button>
                </form>
             </div>
             <div class="nav-item dropdown me-5">
                <form action="<?php echo e(route('locale.setting', 'en')); ?>" method="Get" class="">
                    <button type="submit" class="btn btn-orange me-5" type="button">English</button>
                </form>
             </div>
            <?php if(!Auth::check()): ?>
                <form class="d-flex" role="right">
                    <div class="ms-auto pe-2">
                        <button class="btn btn-orange mx-0" type="button"><a class="nav-link active" href="<?php echo e(route('index_register')); ?>"><?php echo app('translator')->get('attribute.register'); ?></a></button>
                        <button class="btn btn-orange me-5" type="button"><a class="nav-link active" href="<?php echo e(route('index_login')); ?>"><?php echo app('translator')->get('attribute.Login'); ?></a></button>
                    </div>
                </form>
            <?php else: ?>
                <form action="<?php echo e(route('logout')); ?>" method="POST" class="">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-orange me-5" type="button"><?php echo app('translator')->get('attribute.logout'); ?></button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</Header>
<?php /**PATH C:\Users\Asus\OneDrive\Documents\Semester 5\Web Programming\final-exam\resources\views/templete/header.blade.php ENDPATH**/ ?>